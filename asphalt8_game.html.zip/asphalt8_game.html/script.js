let player = document.getElementById("player");
let scoreEl = document.getElementById("score");
let countdownEl = document.getElementById("countdown");
let engineSound = document.getElementById("engineSound");
let road = document.getElementById("road");
let carSelect = document.getElementById("carSelect");

let lanes = [25, 145, 265];
let currentLane = 1;

let speed = 5;
let score = 0;
let gameStarted = false;
let enemies = [];
let nitroActive = false;

/* Car selection */
function chooseCar(src) {
    player.src = src;
    carSelect.style.display = "none";
    startCountdown();
}

/* Countdown */
function startCountdown() {
    let count = 3;
    countdownEl.innerText = count;
    let timer = setInterval(() => {
        countdownEl.innerText = count;
        count--;
        if (count < 0) {
            countdownEl.innerText = "GO!";
            gameStarted = true;
            engineSound.play(); // start engine sound
            setTimeout(() => countdownEl.style.display = "none", 1000);
            clearInterval(timer);
        }
    }, 1000);
}

/* Keyboard control */
document.addEventListener("keydown", e => {
    if (!gameStarted) return;
    if (e.key === "ArrowLeft" && currentLane > 0) currentLane--;
    if (e.key === "ArrowRight" && currentLane < 2) currentLane++;
    player.style.left = lanes[currentLane] + "px";
});

/* Nitro boost */
function useNitro() {
    if (!gameStarted || nitroActive) return;
    nitroActive = true;
    speed += 5;
    engineSound.playbackRate = 1.5;
    setTimeout(() => {
        speed -= 5;
        nitroActive = false;
        engineSound.playbackRate = 1;
    }, 2000);
}

/* Create enemy car */
function createEnemy() {
    if (!gameStarted) return;
    let enemy = document.createElement("div");
    enemy.classList.add("enemy");
    let lane = lanes[Math.floor(Math.random() * 3)];
    enemy.style.left = lane + "px";
    enemy.style.top = "-150px";
    road.appendChild(enemy);
    enemies.push(enemy);
}

/* Move enemies & collision detection */
function moveEnemies() {
    for (let i = enemies.length - 1; i >= 0; i--) {
        let enemy = enemies[i];
        enemy.style.top = parseInt(enemy.style.top) + speed + "px";

        let playerRect = player.getBoundingClientRect();
        let enemyRect = enemy.getBoundingClientRect();
        if (
            playerRect.left < enemyRect.left + enemyRect.width &&
            playerRect.left + playerRect.width > enemyRect.left &&
            playerRect.top < enemyRect.top + enemyRect.height &&
            playerRect.height + playerRect.top > enemyRect.top
        ) {
            alert("CRASH! Game Over");
            engineSound.pause();
            location.reload();
        }

        if (parseInt(enemy.style.top) > road.offsetHeight) {
            road.removeChild(enemy);
            enemies.splice(i, 1);
            score++;
            scoreEl.innerText = score;
            if (score % 5 === 0) speed++; // gradually increase speed
        }
    }
}

/* Game loop */
setInterval(() => {
    if (!gameStarted) return;
    moveEnemies();
}, 20);

/* Spawn enemies every 1.5 sec */
setInterval(createEnemy, 1500);
